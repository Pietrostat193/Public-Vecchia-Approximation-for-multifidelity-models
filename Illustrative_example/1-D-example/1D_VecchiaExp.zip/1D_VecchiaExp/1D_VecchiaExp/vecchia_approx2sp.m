function result = vecchia_approx2sp(locations, hyp, D, nn, eps)
    if nargin < 4
        nn = 15;
    end
    if nargin < 5
        eps = 1e-10;
    end
    
    [n, ~] = size(locations);
    if nn > n - 1
        error('nn > n - 1');
    end
    
    Di = sparse(n, n); % Initialize sparse Di
    B = speye(n); % Initialize sparse identity matrix for B
    neighbors = cell(n, 1);
    
    for i = 1:n
        % Determine neighbors
        if i <= nn + 1
            n_ind = 1:(i - 1);
        else
            [~, sorted_idx] = sort(D(1:(i - 1), i));
            n_ind = sorted_idx(1:nn);
        end
        neighbors{i} = n_ind;
        
        if i == 1
            Di(1, 1) = 1 / k(locations(1, :), locations(1, :), hyp, 0);
        else
            if length(n_ind) == 1
                add_diag = eps;
            else
                add_diag = diag(repmat(eps, length(n_ind), 1));
            end
            
            Sigma_nind_nind = k(locations(n_ind, :), locations(n_ind, :), hyp, 0);
            Sigma_i_nind = k(locations(i, :), locations(n_ind, :), hyp, 0);
            Sigma_i_i = k(locations(i, :), locations(i, :), hyp, 0);
            
            % Ai that express the covariance between the current point i
            % and its neighbors in terms of the covariances among the neighbors themselves.
            Ai = (Sigma_nind_nind + add_diag) \ Sigma_i_nind';
            B(i, n_ind) = -Ai';
            Di(i, i) = 1 / (Sigma_i_i - sum(Sigma_i_nind .* Ai'));
        end
    end
    
    % Convert Di and B to sparse matrices if not already
    Di = sparse(Di);
    B = sparse(B);
    
    result.Di = Di;
    result.B = B;
    result.neighbors = neighbors;
end
