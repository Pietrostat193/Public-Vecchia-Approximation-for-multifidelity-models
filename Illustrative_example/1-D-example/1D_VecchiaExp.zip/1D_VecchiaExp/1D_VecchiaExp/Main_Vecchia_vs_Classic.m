% Load data
load("data_for_vecchia1d.csv");

surrogate = data_for_vecchia1d(:,1);
target    = data_for_vecchia1d(:,2);

% Set random seed and generate a random start index for the missing gap
missing_length = 192;
seed = 12345 + (1 * 6);
rng(seed);

% keep the +/-200 window inside the series
start_idx = randi([500, length(target) - 400]);
end_idx   = start_idx + missing_length - 1;

% Create missing data sequence in 'target'
missing_data = target;
actual_missing_values = target(start_idx:end_idx);
missing_data(start_idx:end_idx) = NaN;

% Extract data around the missing gap for Gaussian Process Regression
Y = missing_data((start_idx - 200):(end_idx + 200));
X = (start_idx - 200:end_idx + 200)';          % raw indices for the window
observed_Y = ~isnan(Y);

% Initial hyperparameters and model info
hyp = [log([1 1 1 1]) 1 -4 -4];
global ModelInfo;
ModelInfo.hyp          = hyp;
ModelInfo.jitter       = 1e-6;
ModelInfo.nn_size      = 50;
ModelInfo.Vecchia_approx = "parallel";
ModelInfo.numWorkers   = 4;

% Define input and output data for the model
% Window-normalised axis (start at 1)
x0 = (start_idx - 201);                         % shift so first X becomes 1
X_norm = X - x0;                                % 1 .. window_length

% Observed HF/LF in the window (decimated by 3 as in your code)
obs_x_all = X(observed_Y) - x0;
obs_y_all = Y(observed_Y);
ModelInfo.X_H = obs_x_all(1:3:end);
ModelInfo.y_H = obs_y_all(1:3:end);

ModelInfo.X_L = X_norm;                         % predictions expect this axis
ModelInfo.y_L = surrogate(X);                   % LF on same window

% Optimisation
options = optimoptions('fminunc', ...
    'Algorithm', 'quasi-newton', ...
    'Display', 'iter', ...
    'TolFun', 1e-12, ...
    'TolX', 1e-12, ...
    'MaxFunctionEvaluations', 2000);

[hyp_classic, ~] = fminunc(@likelihood, hyp, options);

[MF_predicted, hyp_optimized, fval] = optimize_and_predict_vecchia(ModelInfo);
[hyp_vecchia, ~] = fminunc(@likelihoodVecchia31, hyp, options);
a = optimize_and_predict_vecchia(ModelInfo);

% Prediction with Classic and Vecchia models
ModelInfo.hyp = hyp_classic;
[MF_predicted_classic, var_MF] = predictor_f_H(ModelInfo.X_L);

ModelInfo.hyp = hyp_vecchia;
likelihoodVecchia31(hyp_vecchia);
MF_predicted_vecchia = predictor_vecchia(ModelInfo.X_L);

% ----- Plot: use the SAME normalised x-axis for everything -----
% Missing segment in normalised coordinates:
miss_x_norm = (start_idx:end_idx) - x0;         % this fixes the misalignment

figure; hold on; grid on;

plot(ModelInfo.X_H, ModelInfo.y_H, 'o', 'MarkerSize', 10, 'LineWidth', 2, ...
    'Color', 'blue', 'DisplayName', 'Observed LF Data (window)');

plot(miss_x_norm, actual_missing_values, 'kx', 'MarkerSize', 14, ...
    'LineWidth', 2, 'DisplayName', 'Missing Data');

plot(ModelInfo.X_L, MF_predicted_classic, 'k', 'LineWidth', 2, ...
    'DisplayName', 'Predicted Classic');

plot(ModelInfo.X_L, MF_predicted_vecchia, 'm', 'LineWidth', 2, ...
    'DisplayName', 'Predicted Vecchia');

title('Comparison of Observed and Predicted Data');
xlabel('Window index'); ylabel('Value');
legend('show', 'Location', 'best');
set(gcf, 'Position', [100, 100, 800, 600]);
set(gca, 'FontSize', 14);
hold off;


% Plot Model Parameters Comparison
parameter_names = {'logsigma1', 'logtheta1', 'logsigma2', 'logtheta2', 'rho', 'logsigma_eps_L', 'logsigma_eps_H'};
figure; hold on; grid on;
bar(1:7, hyp_classic, 'BarWidth', 0.4, 'FaceColor', 'blue', 'DisplayName', 'Classic Model');
bar(1.4:7.4, hyp_vecchia, 'BarWidth', 0.4, 'FaceColor', 'magenta', 'DisplayName', 'Vecchia Model');
title('Comparison of Model Parameters');
xlabel('Parameters'); ylabel('Values');
xticks(1.2:7.2); xticklabels(parameter_names);
legend('show');
set(gcf, 'Position', [100, 100, 1000, 600]); set(gca, 'FontSize', 14);
hold off;
