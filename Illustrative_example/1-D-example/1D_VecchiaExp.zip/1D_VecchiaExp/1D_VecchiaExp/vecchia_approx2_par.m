function [result] = vecchia_approx2_par(locations, hyp, D, nn, eps)
if nargin < 4
    nn = 15;
end
if nargin < 5
    eps = 1e-10;
end

[n, ~] = size(locations);
if nn > n - 1
    error('nn > n - 1');
end

%% Initialize cell arrays to store parallel results
neighbors = cell(n, 1);
% Initialize sparse identity matrix for B
B_cell = cell(n,1);
% Initialize sparse Di
Di_cell = cell(n,1);

parfor i = 1:n
    % Determine neighbors
    if i <= nn + 1
        n_ind = 1:(i - 1);
    else
        [~, sorted_idx] = sort(D(1:(i - 1), i));
        n_ind = sorted_idx(1:nn);
    end
    neighbors{i} = n_ind;

    B = zeros(1,length(n_ind)); % Initialize sparse identity matrix for B
    if i == 1
        Di_cell{i} = 1 / k(locations(1, :), locations(1, :), hyp, 0);
    else
        if length(n_ind) == 1
            add_diag = eps;
        else
            add_diag = diag(repmat(eps, length(n_ind), 1));
        end

        Sigma_nind_nind = k(locations(n_ind, :), locations(n_ind, :), hyp, 0);
        Sigma_i_nind = k(locations(i, :), locations(n_ind, :), hyp, 0);
        Sigma_i_i = k(locations(i, :), locations(i, :), hyp, 0);

        % Ai that express the covariance between the current point i
        % and its neighbors in terms of the covariances among the neighbors themselves.
        Ai = (Sigma_nind_nind + add_diag) \ Sigma_i_nind';
        B(1, n_ind) = -Ai';
        B_cell{i} = B;
        Di_cell{i} = 1 / (Sigma_i_i - sum(Sigma_i_nind .* Ai'));
    end
end

B_mat = speye(n,n);
Di_mat = speye(n,n);
for i = 1:n
    nb = length(B_cell{i});
    B_mat(i,1:nb) = B_cell{i};
    Di_mat(i,i) = Di_cell{i};
end

result.Di = Di_mat;
result.B = B_mat;
result.neighbors = neighbors;

end
