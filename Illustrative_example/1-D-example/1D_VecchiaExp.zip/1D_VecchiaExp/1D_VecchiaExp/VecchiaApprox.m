function [Di, B, neighbors, U] = VecchiaApprox(Sigma, D, nn, eps)
    if nargin < 4
        eps = 1e-10;
    end
    if nargin < 3
        nn = 15;
    end

    n = size(Sigma, 1);
    if nn > n - 1
        error('nn > n - 1');
    end

    Di = zeros(n, n);
    B = eye(n);
    U=zeros(n,n);
    neighbors = cell(n, 1);

    for i = 1:n
        % Determine neighbors
       if i <= nn + 1
            n_ind = 1:(i - 1);
        else
            [~, sorted_idx] = sort(D(1:(i - 1), i));
            n_ind = sorted_idx(1:nn);
        end

        neighbors{i} = n_ind;
        if i == 1
            Di(1, 1) = 1 / Sigma(1, 1);
        else
            if length(n_ind) == 1
                add_diag = eps;
            else
                add_diag = diag(repmat(eps, length(n_ind), 1));
            end
            % Compute Ai
            Ai = (Sigma(n_ind, n_ind) + add_diag) \ Sigma(i,n_ind)';
            B(i, n_ind) = -Ai;
            Di(i, i) = 1 / (Sigma(i, i) - sum(Sigma(i, n_ind) .* Ai'));
            %cholesky factor
            U(i,n_ind)=-Ai*Di(i,i)^(-1/2);
        end
    end
    U= U + (Di^(-1/2));
end
