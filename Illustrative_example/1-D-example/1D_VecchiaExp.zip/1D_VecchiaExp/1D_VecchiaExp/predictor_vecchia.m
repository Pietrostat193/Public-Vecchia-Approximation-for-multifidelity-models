function [mean_star]=predictor_vecchia(x_star)

global ModelInfo
global PredictionVecchia
X_L = ModelInfo.X_L;
X_H = ModelInfo.X_H;
y_L = ModelInfo.y_L;
y_H = ModelInfo.y_H;
hyp = ModelInfo.hyp;
rho = hyp(end-2);

D = size(X_H,2);

y = [y_L; y_H];

SIy=ModelInfo.SIy;

psi1 = rho*k(x_star, X_L, hyp(1:D+1),0);
psi2 = rho^2*k(x_star, X_H, hyp(1:D+1),0) + k(x_star, X_H, hyp(D+2:2*D+2),0);
q1 = [psi1 psi2];

PredictionVecchia.psi1=psi1;
PredictionVecchia.psi2=psi2;
PredictionVecchia.q=q1;


% calculate prediction
mean_star = q1*SIy;

