function [W_inv, log_det_W] = inverse_using_cholesky(W)
    % This function computes the inverse of a positive definite matrix W
    % using its Cholesky decomposition.
    %
    % Input:
    % - W: A positive definite matrix
    %
    % Output:
    % - W_inv: The inverse of the matrix W
    
    % Ensure the matrix is symmetric
    %if ~isequal(W, W')
    %    error('The input matrix must be symmetric.');
    %end
    
% Perform the Cholesky decomposition
L = chol(W, 'lower');
% Compute the inverse of L
L_inv = inv(L);

% Compute the inverse of W using the Cholesky factor
W_inv = L_inv' * L_inv;

log_det_W = 2*sum(log(diag(L)));
end
