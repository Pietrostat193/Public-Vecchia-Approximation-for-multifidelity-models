function [NLML] = likelihoodVecchia31(hyp)
    % likelihoodVecchia3: Computes the negative log-marginal likelihood (NLML)
    % using Vecchia approximations for a Gaussian Process model with low- and high-fidelity data.
    %
    % Inputs:
    %   - hyp: Hyperparameters vector for optimization
    %
    % Outputs:
    %   - NLML: Negative log-marginal likelihood value
    
    % Load global ModelInfo parameters
    global ModelInfo
    X_L = ModelInfo.X_L;  % Low-fidelity inputs
    X_H = ModelInfo.X_H;  % High-fidelity inputs
    y_L = ModelInfo.y_L;  % Low-fidelity outputs
    y_H = ModelInfo.y_H;  % High-fidelity outputs
    Vecchia_approx = ModelInfo.Vecchia_approx;
    jitter = ModelInfo.jitter;
    nn_size = ModelInfo.nn_size;

    % Derived hyperparameters
    sigma_eps_H = exp(hyp(end));
    sigma_eps_L = exp(hyp(end-1));
    rho = hyp(end-2);

    % Problem dimensions
    [N_L, Dim] = size(X_L);
    N_H = size(X_H, 1);
    N = N_L + N_H;
    y = [y_L; y_H];  % Combined output vector

    % Define Vecchia approximation methods
    function [Ki_L, Ki_D, log_det_K_L, log_det_K_D] = vecchia_classic(K_LL, K_DD, X_L, X_H, jitter)
        % Classic Vecchia approximation using K_LL and K_DD
        D_L = pdist2(X_L, X_L);
        [Di_L, B_L] = VecchiaApprox(K_LL, D_L, nn_size, jitter);
        log_det_K_L = sum(log(diag(Di_L)));
        Ki_L = sparse(B_L)' * sparse(Di_L) * sparse(B_L);
        
        D_H = pdist2(X_H, X_H);
        [Di_H, B_H] = VecchiaApprox(K_DD, D_H, nn_size, jitter);
        log_det_K_D = sum(log(diag(Di_H)));
        Ki_D = sparse(B_H)' * sparse(Di_H) * sparse(B_H);
    end


    function [Ki_L, Ki_D] = vecchia_parallel(X_L, X_H, jitter)
        % Parallel Vecchia approximation
        D_L = pdist2(X_L, X_L);
        result = vecchia_approx2_par(X_L, hyp(1:Dim+1), D_L, 20, jitter);
        Ki_L = result.B' * result.Di * result.B;
        log_det_K_L = full(sum(log(diag(result.Di))));

        D_H = pdist2(X_H, X_H);
        result = vecchia_approx2_par(X_H, hyp(Dim+2:2*Dim+2), D_H, 20, jitter);
        Ki_D = result.B' * result.Di * result.B;
        log_det_K_D = full(sum(log(diag(result.Di))));
    end

    % Choose Vecchia approximation method
    
    switch Vecchia_approx
        case 'classic'
            K_LL = k(X_L, X_L, hyp(1:Dim+1), 0);
            K_DD = k(X_H, X_H, hyp(Dim+2:2*Dim+2), 0);
    
            [Ki_L, Ki_D, log_det_K_L, log_det_K_D] = vecchia_classic(K_LL, K_DD, X_L, X_H, jitter);
        case 'parallel'
            [Ki_L, Ki_D] = vecchia_parallel(X_L, X_H, jitter);
        otherwise
            error('Unknown Vecchia approximation method.');
    end

    % Construct block-diagonal inverse covariance matrix W_inv and log determinant
    W_inv = spblkdiag(Ki_L, Ki_D);
    log_det_W = -(log_det_K_D + log_det_K_L);

    % Construct matrices for Woodbury identity application
    [A, D, D_inv, Z21, Z1] = construct_matrices(X_L, X_H, rho, sigma_eps_L, sigma_eps_H);
    A = sparse(A); D = sparse(D); D_inv = sparse(D_inv);

    % Compute intermediate matrix H and its inverse
    H = W_inv + A' * D_inv * A + speye(size(W_inv)) * jitter;
    [Hi, log_det_H] = inverse_using_cholesky(H);

    % Compute K_inv using Woodbury identity
    K_inv = D_inv - D_inv * A * Hi * A' * D_inv;
    ModelInfo.K_inv = K_inv;  % Store K_inv for later use

    % Compute SIy directly without explicitly forming K_inv
    Dy = D_inv * y;
    SIy = Dy - D_inv * A * Hi * (A' * Dy);
    ModelInfo.SIy = SIy;  % Store SIy in ModelInfo for later use (prediction)

    % Log-determinant components
    log_det_D = sum(log(diag(D)));

    % Negative log-marginal likelihood (NLML) computation
    term1 = 0.5 * (y' * SIy);
    term2 = 0.5 * (log_det_W + log_det_H + log_det_D);
    term3 = 0.5 * N * log(2 * pi);
    NLML = term1 + term2 + term3;
end

