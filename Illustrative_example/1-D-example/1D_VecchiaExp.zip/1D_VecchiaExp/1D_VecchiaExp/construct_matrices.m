function [A, D, DI,Z21,Z1] = construct_matrices(X_L, X_H, rho, nugget_s1, nugget_s2)
    % Define the dimensions and parameters
    
   
    N_L = size(X_L, 1);  % Number of low fidelity (LF) points
    N_H = size(X_H, 1);  % Number of high fidelity (HF) points

% Find the unique locations from X_H and X_L
unique_locations = unique([X_H; X_L], 'rows');

% Number of unique locations (N) and number of rows in X_L (N_L)
N = size(unique_locations, 1);

% Initialize the Z1 matrix with zeros
Z1 = zeros(N_L, N);
% Populate the Z1 matrix
for i = 1:N_L
    % Find the index of the current row of X_L in the unique locations
    [~, idx] = ismember(X_L(i, :), unique_locations, 'rows');
    % Set the corresponding value in Z1 to 1
    Z1(i, idx) = 1;
end

Z21 = zeros(N_H, N);
% Populate the Z21 matrix
for i = 1:N_H
    % Find the index of the current row of X_H in the unique locations
    [~, idx] = ismember(X_H(i, :), unique_locations, 'rows');
    % Set the corresponding value in Z21 to 1
    Z21(i, idx) = rho;
end

    % Create sparse matrix Z21
    %Z21 = sparse(1:n2, index, rho, n2, N1);    
    % Create A matrix of projection
    %In2 = speye(n2);
    In=eye(N_H);
    Zero=zeros(N_L, N_H);
    % Construct the block matrix A
    A_top = [Z1, Zero];
    A_bottom = [Z21, In];
    A = [A_top; A_bottom];
    %jitter=1e-6;
    % Creat1ion of D matrix of errors
    upper_diag = repmat(nugget_s1, N_L, 1);
    lower_diag = repmat(nugget_s2, N_H, 1);
    diag_inv = 1 ./ [upper_diag; lower_diag];
    DI = diag(diag_inv);
    D = diag([upper_diag; lower_diag]);
end
