function [MF_predicted, hyp_optimized, fval] = optimize_and_predict_vecchia(ModelInfo)
    % Set up initial hyperparameters and optimization options
    initial_hyp = ModelInfo.hyp;
 global ModelInfo
    options = optimoptions('fminunc', ...
        'Algorithm', 'quasi-newton', ...
        'Display', 'iter', ...
        'TolFun', 1e-12, ...
        'TolX', 1e-12, ...
        'MaxFunctionEvaluations', 2000);

if ModelInfo.Vecchia_approx=="parallel"
numWorkers = ModelInfo.numWorkers;
if isempty(gcp('nocreate'))
    parpool('Processes', numWorkers);
end
end
    % Run the optimization to find the best hyperparameters
    [hyp_optimized, fval] = fminunc(@(hyp) likelihoodVecchia31(hyp), initial_hyp, options);

    % Update ModelInfo with optimized hyperparameters
    ModelInfo.hyp = hyp_optimized;

    % Generate predictions using the optimized hyperparameters
    x_star = ModelInfo.X_L;
    MF_predicted = predictor_vecchia(x_star);

end
