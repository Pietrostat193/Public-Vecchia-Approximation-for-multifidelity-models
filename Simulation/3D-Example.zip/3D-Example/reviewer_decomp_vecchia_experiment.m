%% sweep_all_sim_conditions_save_results.m
% Sweeps ALL simulation conditions from make_sim_conditions() and saves:
% (A) Exact MFGP (likelihood2Dsp + predict2Dsp)
% (B) Vecchia approx MFGP at fixed hyp_base (likelihoodVecchia_nonstat_GLS + predictVecchia_CM_calibrated2)
% (C) GP predictors (train_and_predict_gpr) Models 1/2/3
%
% Saves a single results struct to disk containing per-condition/per-rep outputs + summaries.

clear; clc;

%% ---------------- USER SETTINGS ----------------
R = 1;                 % replications per simulation condition
trainFrac = 0.3;

sizes = [60, 90];
vecchiaConds = ["MinMax","Corr"];

simConds = make_sim_conditions();    % 1×36 struct array
nSim = numel(simConds);

% exact optimizer
opt = optimoptions('fminunc', ...
    'Algorithm','quasi-newton', ...
    'SpecifyObjectiveGradient', false, ...
    'FiniteDifferenceType','central', ...
    'FiniteDifferenceStepSize',1e-4, ...
    'Display','off', ...
    'MaxIterations', 200, ...
    'MaxFunctionEvaluations', 5000, ...
    'FunctionTolerance',1e-8, ...
    'StepTolerance',1e-8);

max_restarts_exact = 2;
doRMSE = true;

%% ---------------- PREALLOCATE RESULTS ----------------
nM = numel(sizes);
nC = numel(vecchiaConds);

% Top-level results container
Results = struct();
Results.meta = struct();
Results.meta.R = R;
Results.meta.trainFrac = trainFrac;
Results.meta.sizes = sizes;
Results.meta.vecchiaConds = vecchiaConds;
Results.meta.simConds = simConds;
Results.meta.timestamp = string(datetime('now'));

% For each simulation condition, store per-rep and summaries
Results.sim = repmat(struct(), nSim, 1);

%% ---------------- MAIN SWEEP ----------------
for is = 1:nSim
    cfg = simConds(12);
    cfg.n_time=10
    fprintf('\n============================================================\n');
    fprintf('SIM CONDITION %d/%d: %s\n', is, nSim, cfg.name);
    fprintf('============================================================\n');

    % storage per sim condition
    % (A) Exact MFGP
    NLML_exact      = nan(R,1);
    logdet_exact    = nan(R,1);
    quad_exact      = nan(R,1);
    rmse_exact_mfgp = nan(R,1);

    % (C) GP predictors
    rmse_gp1 = nan(R,1);
    rmse_gp2 = nan(R,1);
    rmse_gp3 = nan(R,1);

    % (B) Vecchia approx MFGP (per m, cond)
    NLML_v            = nan(R,nM,nC);
    logdet_v          = nan(R,nM,nC);
    quad_v            = nan(R,nM,nC);
    relErr_alpha      = nan(R,nM,nC);
    relErr_quad       = nan(R,nM,nC);
    relErr_logdet     = nan(R,nM,nC);
    rmse_vecchia_mfgp = nan(R,nM,nC);

    ok_exact = false(R,1);
    ok_v     = false(R,nM,nC);

    for r = 1:R
        fprintf('\n-- Replication %d/%d (sim %d) --\n', r, R, is);

        try
            % deterministic numeric seed per (sim condition, replication)
            seed = 100000*is + r;
            rng(seed);

            out = simulate_data_dynamic(seed, trainFrac, cfg);

            % HF test
            X_test = [out.HF_test.t, out.HF_test.s1, out.HF_test.s2];
            y_test = out.HF_test.fH(:);

            %% ---------- Build ModelInfo for Exact MFGP ----------
            clear global ModelInfo
            global ModelInfo
            ModelInfo = struct();

            ModelInfo.X_H = [out.HF_train.t, out.HF_train.s1, out.HF_train.s2];
            ModelInfo.y_H = out.HF_train.fH(:);

            ModelInfo.X_L = [out.LF.t, out.LF.s1, out.LF.s2];
            ModelInfo.y_L = out.LF.fL(:);

            ModelInfo.cov_type    = "RBF";
            ModelInfo.kernel      = "RBF";
            ModelInfo.combination = "multiplicative";
            ModelInfo.jitter      = 1e-6;

            ModelInfo.MeanFunction = "zero";
            ModelInfo.RhoFunction  = "constant";

            %% ---------- (A) Fit Exact MFGP hyp_base ----------
            fprintf('   [A] Fitting Exact MFGP hyp_base (likelihood2Dsp)...\n');

            bestF = inf; bestHyp = [];
            for att = 1:max_restarts_exact
                hyp_init = rand(11,1);
                opt2 = optimoptions(opt, 'TypicalX', 1 + abs(hyp_init));
                try
                    [htry, ftry] = fminunc(@likelihood2Dsp, hyp_init, opt2);
                    if isfinite(ftry) && ftry < bestF
                        bestF = ftry; bestHyp = htry;
                    end
                catch
                end
            end

            if isempty(bestHyp)
                warning('Exact fit failed at sim=%d rep=%d. Skipping rep.', is, r);
                continue;
            end

            hyp_base = bestHyp(:);
            ModelInfo.hyp = hyp_base;

            % evaluate exact once to populate ModelInfo fields
            NLML_exact(r) = likelihood2Dsp(hyp_base);

            y_joint = [ModelInfo.y_L; ModelInfo.y_H];
            alpha_e = ModelInfo.alpha;
            logdet_exact(r) = 2 * ModelInfo.log_det_classic;
            quad_exact(r)   = y_joint' * alpha_e;

            ok_exact(r) = true;

            if doRMSE
                pred_exact = predict2Dsp(X_test);
                rmse_exact_mfgp(r) = sqrt(mean((pred_exact(:) - y_test).^2));
            end

            fprintf('   Exact MFGP: NLML=%.3f logdet=%.3f quad=%.3f RMSE=%.4f\n', ...
                NLML_exact(r), logdet_exact(r), quad_exact(r), rmse_exact_mfgp(r));

            %% ---------- (C) GP predictors (train_and_predict_gpr) ----------
            fprintf('   [C] Running GP predictors (train_and_predict_gpr)...\n');

            ModelInfo2 = struct();
            ModelInfo2.X_L = ModelInfo.X_L;  ModelInfo2.y_L = ModelInfo.y_L;
            ModelInfo2.X_H = ModelInfo.X_H;  ModelInfo2.y_H = ModelInfo.y_H;

            [Y_pred1_all, ~, Y_pred2_all, ~, Y_pred3_all, ~] = train_and_predict_gpr(ModelInfo2);

            Y_pred1 = Y_pred1_all(out.test_row_idx);
            Y_pred2 = Y_pred2_all(out.test_row_idx);
            Y_pred3 = Y_pred3_all(out.test_row_idx);

            y_test = y_test(:);
            rmse_gp1(r) = sqrt(mean((Y_pred1(:) - y_test).^2));
            rmse_gp2(r) = sqrt(mean((Y_pred2(:) - y_test).^2));
            rmse_gp3(r) = sqrt(mean((Y_pred3(:) - y_test).^2));

            fprintf('   GP predictors RMSE: GP1=%.4f | GP2=%.4f | GP3=%.4f\n', ...
                rmse_gp1(r), rmse_gp2(r), rmse_gp3(r));

            %% ---------- (B) Vecchia approx MFGP at fixed hyp_base ----------
            fprintf('   [B] Evaluating Vecchia MFGP at fixed hyp_base...\n');

            for jc = 1:nC
                ModelInfo.conditioning = vecchiaConds(jc);

                for im = 1:nM
                    nn = sizes(im);
                    ModelInfo.nn_size   = nn;
                    ModelInfo.cand_mult = max(10, nn);

                    % force neighbor cache rebuild
                    if isfield(ModelInfo,'vecchia_idxL'), ModelInfo = rmfield(ModelInfo,'vecchia_idxL'); end
                    if isfield(ModelInfo,'vecchia_idxH'), ModelInfo = rmfield(ModelInfo,'vecchia_idxH'); end

                    try
                        nlml_here = likelihoodVecchia_nonstat_GLS(hyp_base);

                        dbg = ModelInfo.debug_vecchia;
                        alpha_v = dbg.SIy;  % raw K^{-1}y (as stored in your code)

                        N = numel(y_joint);
                        quad_v_here = y_joint' * alpha_v;
                        logdet_v_here = 2*(nlml_here - 0.5*quad_v_here - 0.5*N*log(2*pi));

                        NLML_v(r,im,jc)   = nlml_here;
                        quad_v(r,im,jc)   = quad_v_here;
                        logdet_v(r,im,jc) = logdet_v_here;

                        relErr_alpha(r,im,jc)  = norm(alpha_v - alpha_e) / max(norm(alpha_e), 1e-12);
                        relErr_quad(r,im,jc)   = abs(quad_v_here - quad_exact(r)) / max(abs(quad_exact(r)), 1e-12);
                        relErr_logdet(r,im,jc) = abs(logdet_v_here - logdet_exact(r)) / max(abs(logdet_exact(r)), 1e-12);

                        if doRMSE
                            yhat_v = predictVecchia_CM_calibrated2(X_test);
                            rmse_vecchia_mfgp(r,im,jc) = sqrt(mean((yhat_v(:) - y_test).^2));
                        end

                        ok_v(r,im,jc) = true;

                        fprintf('     Vecchia MFGP cond=%s m=%d | relErr(alpha)=%.2e relErr(logdet)=%.2e RMSE=%.4f\n', ...
                            string(vecchiaConds(jc)), nn, relErr_alpha(r,im,jc), relErr_logdet(r,im,jc), rmse_vecchia_mfgp(r,im,jc));

                    catch ME
                        warning('Vecchia failed sim=%d rep=%d cond=%s m=%d: %s', ...
                            is, r, string(vecchiaConds(jc)), nn, ME.message);
                    end
                end
            end

        catch ME
            warning('Sim condition %d rep %d failed: %s', is, r, ME.message);
            continue;
        end
    end

    %% ---------------- SUMMARIES FOR THIS SIM CONDITION ----------------
    idxE = ok_exact;
    nE = sum(idxE);

    exact_summary = table();
    exact_summary.sim_id = is;
    exact_summary.sim_name = string(cfg.name);
    exact_summary.n_success = nE;
    exact_summary.mean_NLML   = mean(NLML_exact(idxE), 'omitnan');
    exact_summary.mean_logdet = mean(logdet_exact(idxE),'omitnan');
    exact_summary.mean_quad   = mean(quad_exact(idxE),  'omitnan');
    if doRMSE
        exact_summary.mean_RMSE_exactMFGP = mean(rmse_exact_mfgp(idxE),'omitnan');
    end

    gp_summary = table();
    gp_summary.sim_id = is;
    gp_summary.sim_name = string(cfg.name);
    gp_summary.n_success = nE;
    gp_summary.mean_RMSE_GP1 = mean(rmse_gp1(idxE),'omitnan');
    gp_summary.mean_RMSE_GP2 = mean(rmse_gp2(idxE),'omitnan');
    gp_summary.mean_RMSE_GP3 = mean(rmse_gp3(idxE),'omitnan');

    % Vecchia summary rows
    vecchia_rows = [];
    for jc = 1:nC
        for im = 1:nM
            idx = ok_v(:,im,jc) & ok_exact;
            ns = sum(idx);

            S = table();
            S.sim_id = is;
            S.sim_name = string(cfg.name);
            S.Conditioning = vecchiaConds(jc);
            S.m = sizes(im);
            S.n_success = ns;

            S.mean_relErr_alpha  = mean(relErr_alpha(idx,im,jc),  'omitnan');
            S.mean_relErr_logdet = mean(relErr_logdet(idx,im,jc), 'omitnan');
            S.mean_relErr_quad   = mean(relErr_quad(idx,im,jc),   'omitnan');

            if doRMSE
                S.mean_RMSE_vecchiaMFGP = mean(rmse_vecchia_mfgp(idx,im,jc), 'omitnan');
            end

            vecchia_rows = [vecchia_rows; S]; %#ok<AGROW>
        end
    end

    %% ---------------- SAVE INTO Results struct ----------------
    Results.sim(is).cfg = cfg;

    Results.sim(is).per_rep = struct();
    Results.sim(is).per_rep.ok_exact = ok_exact;
    Results.sim(is).per_rep.NLML_exact = NLML_exact;
    Results.sim(is).per_rep.logdet_exact = logdet_exact;
    Results.sim(is).per_rep.quad_exact = quad_exact;
    Results.sim(is).per_rep.rmse_exact_mfgp = rmse_exact_mfgp;

    Results.sim(is).per_rep.rmse_gp1 = rmse_gp1;
    Results.sim(is).per_rep.rmse_gp2 = rmse_gp2;
    Results.sim(is).per_rep.rmse_gp3 = rmse_gp3;

    Results.sim(is).per_rep.ok_v = ok_v;
    Results.sim(is).per_rep.NLML_v = NLML_v;
    Results.sim(is).per_rep.logdet_v = logdet_v;
    Results.sim(is).per_rep.quad_v = quad_v;
    Results.sim(is).per_rep.relErr_alpha = relErr_alpha;
    Results.sim(is).per_rep.relErr_logdet = relErr_logdet;
    Results.sim(is).per_rep.relErr_quad = relErr_quad;
    Results.sim(is).per_rep.rmse_vecchia_mfgp = rmse_vecchia_mfgp;

    Results.sim(is).summary = struct();
    Results.sim(is).summary.exact = exact_summary;
    Results.sim(is).summary.gp = gp_summary;
    Results.sim(is).summary.vecchia = vecchia_rows;

    % Also build an "advantage" table for this sim condition (optional)
    if doRMSE
        adv_tbl = table();
        adv_tbl.sim_id = is;
        adv_tbl.sim_name = string(cfg.name);
        adv_tbl.mean_adv_GP1_minus_ExactMFGP = mean(rmse_gp1(idxE) - rmse_exact_mfgp(idxE), 'omitnan');
        adv_tbl.mean_adv_GP2_minus_ExactMFGP = mean(rmse_gp2(idxE) - rmse_exact_mfgp(idxE), 'omitnan');
        adv_tbl.mean_adv_GP3_minus_ExactMFGP = mean(rmse_gp3(idxE) - rmse_exact_mfgp(idxE), 'omitnan');
        Results.sim(is).summary.adv = adv_tbl;
    end

    fprintf('\n[SIM %d] Summary: ExactMFGP RMSE=%.4f | GP1=%.4f GP2=%.4f GP3=%.4f\n', ...
        is, exact_summary.mean_RMSE_exactMFGP, gp_summary.mean_RMSE_GP1, gp_summary.mean_RMSE_GP2, gp_summary.mean_RMSE_GP3);
end

%% ---------------- GLOBAL AGGREGATION TABLES (ALL SIM CONDITIONS) ----------------
ExactAll = [];
GPAll = [];
VecchiaAll = [];
AdvAll = [];

for is = 1:nSim
    ExactAll = [ExactAll; Results.sim(is).summary.exact]; %#ok<AGROW>
    GPAll    = [GPAll;    Results.sim(is).summary.gp];    %#ok<AGROW>
    VecchiaAll = [VecchiaAll; Results.sim(is).summary.vecchia]; %#ok<AGROW>
    if isfield(Results.sim(is).summary,'adv')
        AdvAll = [AdvAll; Results.sim(is).summary.adv]; %#ok<AGROW>
    end
end

Results.global = struct();
Results.global.ExactAll = ExactAll;
Results.global.GPAll = GPAll;
Results.global.VecchiaAll = VecchiaAll;
Results.global.AdvAll = AdvAll;

%% ---------------- SAVE TO DISK ----------------
outFile = sprintf('SweepResults_%s.mat', datestr(now,'yyyymmdd_HHMMSS'));
save(outFile, 'Results');

fprintf('\nSaved all results to: %s\n', outFile);

% Display quick ranking by Exact MFGP RMSE (lower is better)
if doRMSE
    [~, ord] = sort(ExactAll.mean_RMSE_exactMFGP, 'ascend');
    disp('Top 10 sim conditions by Exact MFGP RMSE (best -> worst):');
    disp(ExactAll(ord(1:min(10,height(ExactAll))), {'sim_id','sim_name','mean_RMSE_exactMFGP'}));

    % And by GP3 advantage over Exact MFGP (negative means GP3 is better)
    if ~isempty(AdvAll)
        [~, ord2] = sort(AdvAll.mean_adv_GP3_minus_ExactMFGP, 'ascend');
        disp('Top 10 sim conditions where GP3 beats Exact MFGP most (most negative GP3-Exact):');
        disp(AdvAll(ord2(1:min(10,height(AdvAll))), :));
    end
end
