Decomposed Vecchia – Targeted Validation Experiment
---------------------------------------------------
Date: 12-Jan-2026 16:28:16

Files:
  summary_results.csv   -> mean errors over replications
  exact_summary.csv     -> exact GP baseline statistics
  raw_results.mat       -> full arrays (per seed, m, conditioning)
  metadata.mat          -> experiment configuration
  figure_*.pdf/png      -> plots used in the paper

Notes:
  - Vecchia evaluated at fixed exact hyperparameters.
  - Failed runs were skipped via continue statements.
